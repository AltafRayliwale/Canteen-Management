package com.example.canteen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CanteenApplicationTests {

	@Test
	void contextLoads() {
	}

}
